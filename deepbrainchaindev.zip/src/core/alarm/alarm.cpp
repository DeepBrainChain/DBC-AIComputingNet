﻿#include "alarm.h"


void alarm::alarm_debug(uint32_t type, const char * psz)
{
    
}

void alarm::alarm_info(uint32_t type, const char * psz)
{
    
}

void alarm::alarm_warning(uint32_t type, const char * psz)
{
    
}

void alarm::alarm_critical(uint32_t type, const char * psz)
{
    
}

void alarm::alarm_info_alive()
{
    
}

void alarm::alarm_critical_mpu_err()
{
    
}

void alarm::alarm_critical_mag_err()
{
    
}

void alarm::alarm_critical_ms5611_err()
{
    
}



