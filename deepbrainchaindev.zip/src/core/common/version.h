/*********************************************************************************
*  Copyright (c) 2017-2018 DeepBrainChain core team
*  Distributed under the MIT software license, see the accompanying
*  file COPYING or http://www.opensource.org/licenses/mit-license.php
* file name        ��version.h
* description    ��core version
* date                  : 2018.02.02
* author            ��Bruce Feng
**********************************************************************************/
#pragma once

//major version . minor version. bug fix version
//version should be revised when official release
#define CORE_VERSION                        "0.1.0"
